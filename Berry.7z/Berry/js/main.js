$(document).ready(function(){
  setTimeout(function(){$('#myModal').modal('show');}, 1000);
});


